#!/usr/bin/env sh

../../build/tools/caffe train --solver=prostate_solver.prototxt
